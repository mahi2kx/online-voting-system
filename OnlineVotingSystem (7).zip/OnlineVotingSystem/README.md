# Online Voting System
### Java + JDBC + MySQL | Console Application

---

## Project Structure

```
OnlineVotingSystem/
├── database_setup.sql          ← Run this in MySQL first
├── README.md
└── src/
    └── voting/
        ├── DBConnection.java   ← JDBC connection utility
        ├── Voter.java          ← Voter model
        ├── VoterDAO.java       ← Voter DB operations
        ├── Candidate.java      ← Candidate model
        ├── CandidateDAO.java   ← Candidate DB operations
        ├── Vote.java           ← Vote model
        ├── VoteDAO.java        ← Vote DB operations
        └── Main.java           ← Entry point + console menu
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| Java JDK | 17+ (or 11+) |
| MySQL | 8.0+ |
| MySQL Connector/J | 8.x JAR |

Download MySQL Connector/J from:
https://dev.mysql.com/downloads/connector/j/

---

## Step 1 – Database Setup

Open MySQL and run:

```sql
SOURCE /path/to/database_setup.sql;
```

Or paste the contents of `database_setup.sql` directly into MySQL Workbench / CLI.

---

## Step 2 – Configure DB Credentials

Open `src/voting/DBConnection.java` and update:

```java
private static final String DB_URL      = "jdbc:mysql://localhost:3306/online_voting?useSSL=false&serverTimezone=UTC";
private static final String DB_USER     = "root";           // ← your MySQL username
private static final String DB_PASSWORD = "your_password";  // ← your MySQL password
```

---

## Step 3 – Compile

```bash
# From the project root
javac -cp mysql-connector-j-8.x.x.jar -d out src/voting/*.java
```

---

## Step 4 – Run

```bash
java -cp "out:mysql-connector-j-8.x.x.jar" voting.Main
```

> On Windows replace `:` with `;` in the classpath:
> `java -cp "out;mysql-connector-j-8.x.x.jar" voting.Main`

---

## Features

| # | Feature | Notes |
|---|---------|-------|
| 1 | Register Voter | Username must be unique |
| 2 | Login Voter | Validates username + password |
| 3 | Add Candidate | Name + party required |
| 4 | View Candidates | Table view with IDs |
| 5 | Cast Vote | Login required; one vote per voter |
| 6 | View Results | Live bar chart with vote % |
| 7 | Exit | Closes DB connection cleanly |

---

## Database Schema

```sql
voters     (id PK, name, username UNIQUE, password)
candidates (id PK, name, party)
votes      (id PK, voter_id UNIQUE FK→voters, candidate_id FK→candidates)
```

The `UNIQUE` constraint on `votes.voter_id` enforces one-vote-per-voter at the database level.

---

## OOP Concepts Used

- **Encapsulation** – all model fields are `private` with getters/setters
- **Classes & Objects** – separate model and DAO classes
- **Abstraction** – DAOs hide SQL from `Main.java`
- **PreparedStatement** – prevents SQL injection throughout

---

## Sample Console Output

```
╔══════════════════════════════════════════╗
║       ONLINE VOTING SYSTEM  v1.0         ║
║      Built with Java + JDBC + MySQL      ║
╚══════════════════════════════════════════╝

══════════════ MAIN MENU ══════════════
  1. Register Voter
  2. Login
  3. Add Candidate
  4. View Candidates
  5. Cast Vote        [login required]
  6. View Results
  7. Exit
═══════════════════════════════════════
```
