-- ============================================================
-- Online Voting System - MySQL Database Setup Script
-- Run this script in MySQL before starting the application
-- ============================================================

-- Create and select the database
CREATE DATABASE IF NOT EXISTS online_voting;
USE online_voting;

-- -----------------------------------------------
-- Table: voters
-- Stores registered voter credentials and info
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS voters (
    id       INT          AUTO_INCREMENT PRIMARY KEY,
    name     VARCHAR(100) NOT NULL,
    username VARCHAR(50)  NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);

-- -----------------------------------------------
-- Table: candidates
-- Stores candidates standing for election
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS candidates (
    id    INT          AUTO_INCREMENT PRIMARY KEY,
    name  VARCHAR(100) NOT NULL,
    party VARCHAR(100) NOT NULL
);

-- -----------------------------------------------
-- Table: votes
-- Records each vote cast (voter_id must be unique
-- to prevent duplicate voting)
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS votes (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    voter_id     INT NOT NULL UNIQUE,           -- UNIQUE prevents duplicate votes
    candidate_id INT NOT NULL,
    FOREIGN KEY (voter_id)     REFERENCES voters(id)     ON DELETE CASCADE,
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
);

-- -----------------------------------------------
-- Optional: seed some sample candidates
-- -----------------------------------------------
INSERT IGNORE INTO candidates (name, party) VALUES
    ('Alice Johnson',  'Progressive Party'),
    ('Bob Smith',      'Liberty Alliance'),
    ('Carol Williams', 'United Front');

-- Confirmation message
SELECT 'Database setup complete!' AS Status;
