package voting;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection.java
 * ------------------
 * Utility class that provides a singleton-style MySQL database connection.
 * Uses JDBC DriverManager to connect to the "online_voting" database.
 *
 * Update DB_URL, DB_USER, and DB_PASSWORD to match your MySQL setup.
 */
public class DBConnection {

    // ── Connection parameters ──────────────────────────────────────────────
    private static final String DB_URL      = "jdbc:mysql://localhost:3306/online_voting"
                                            + "?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER     = "root";       // change if needed
    private static final String DB_PASSWORD = "your_password"; // change to your MySQL password

    // Cached connection instance (reused across the session)
    private static Connection connection = null;

    // Private constructor – this class should never be instantiated
    private DBConnection() {}

    /**
     * Returns an open Connection to the online_voting database.
     * If the connection does not yet exist (or has been closed), a new one is created.
     *
     * @return  Connection object ready for use
     * @throws  RuntimeException if the driver or database cannot be reached
     */
    public static Connection getConnection() {
        try {
            // Load the MySQL JDBC driver (required for older JDBC versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create a new connection if none exists or the existing one is closed
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                System.out.println("[DB] Connected to MySQL database successfully.");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("[DB ERROR] MySQL JDBC Driver not found. "
                             + "Add mysql-connector-java JAR to your classpath.");
            throw new RuntimeException(e);
        } catch (SQLException e) {
            System.err.println("[DB ERROR] Could not connect to the database: " + e.getMessage());
            throw new RuntimeException(e);
        }
        return connection;
    }

    /**
     * Closes the shared database connection gracefully.
     * Call this once when the application is shutting down.
     */
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("[DB] Database connection closed.");
            } catch (SQLException e) {
                System.err.println("[DB ERROR] Failed to close connection: " + e.getMessage());
            }
        }
    }
}
