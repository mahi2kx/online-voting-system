package voting;

/**
 * Voter.java
 * -----------
 * Model class (entity) representing a registered voter.
 * Encapsulates voter data: id, name, username, and password.
 *
 * Follows OOP encapsulation – all fields are private and
 * accessed/mutated through public getters and setters.
 */
public class Voter {

    // ── Fields ────────────────────────────────────────────────────────────
    private int    id;
    private String name;
    private String username;
    private String password;

    // ── Constructors ──────────────────────────────────────────────────────

    /** Default (no-arg) constructor. */
    public Voter() {}

    /**
     * Parameterised constructor used when creating a new voter
     * (id is not yet known – assigned by the database).
     */
    public Voter(String name, String username, String password) {
        this.name     = name;
        this.username = username;
        this.password = password;
    }

    /**
     * Full constructor used when reading a voter back from the database.
     */
    public Voter(int id, String name, String username, String password) {
        this.id       = id;
        this.name     = name;
        this.username = username;
        this.password = password;
    }

    // ── Getters ───────────────────────────────────────────────────────────

    public int    getId()       { return id; }
    public String getName()     { return name; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }

    // ── Setters ───────────────────────────────────────────────────────────

    public void setId(int id)             { this.id       = id; }
    public void setName(String name)      { this.name     = name; }
    public void setUsername(String u)     { this.username = u; }
    public void setPassword(String p)     { this.password = p; }

    // ── toString ──────────────────────────────────────────────────────────

    @Override
    public String toString() {
        return "Voter{id=" + id + ", name='" + name + "', username='" + username + "'}";
    }
}
