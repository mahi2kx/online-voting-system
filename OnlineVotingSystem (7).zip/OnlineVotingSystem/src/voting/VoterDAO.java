package voting;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * VoterDAO.java
 * --------------
 * Data Access Object (DAO) for the "voters" table.
 * Provides database operations for voter registration and login.
 *
 * All queries use PreparedStatement to prevent SQL injection.
 */
public class VoterDAO {

    // Shared database connection
    private final Connection conn;

    /** Constructor – obtains a connection from the DBConnection utility. */
    public VoterDAO() {
        this.conn = DBConnection.getConnection();
    }

    // =========================================================================
    // 1. REGISTER VOTER
    // =========================================================================

    /**
     * Inserts a new voter record into the database.
     *
     * @param  voter  Voter object containing name, username, and password
     * @return true   if the insert succeeded; false otherwise
     */
    public boolean registerVoter(Voter voter) {
        // Check if the username is already taken
        if (isUsernameTaken(voter.getUsername())) {
            System.out.println("[!] Username '" + voter.getUsername() + "' is already registered.");
            return false;
        }

        String sql = "INSERT INTO voters (name, username, password) VALUES (?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, voter.getName());
            ps.setString(2, voter.getUsername());
            ps.setString(3, voter.getPassword());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            System.err.println("[DB ERROR] registerVoter: " + e.getMessage());
            return false;
        }
    }

    // =========================================================================
    // 2. LOGIN VOTER
    // =========================================================================

    /**
     * Validates voter credentials and returns the matching Voter object.
     *
     * @param  username  entered username
     * @param  password  entered password
     * @return Voter     if credentials match; null if not found
     */
    public Voter loginVoter(String username, String password) {
        String sql = "SELECT * FROM voters WHERE username = ? AND password = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Map the result row to a Voter object and return it
                return new Voter(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("username"),
                    rs.getString("password")
                );
            }
        } catch (SQLException e) {
            System.err.println("[DB ERROR] loginVoter: " + e.getMessage());
        }
        return null; // Login failed
    }

    // =========================================================================
    // 3. HELPER – check for duplicate username
    // =========================================================================

    /**
     * Returns true if the given username already exists in the voters table.
     *
     * @param  username  the username to check
     * @return boolean
     */
    public boolean isUsernameTaken(String username) {
        String sql = "SELECT id FROM voters WHERE username = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next(); // true if a row was found
        } catch (SQLException e) {
            System.err.println("[DB ERROR] isUsernameTaken: " + e.getMessage());
            return false;
        }
    }
}
